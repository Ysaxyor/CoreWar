package grille;

public class main {
	public static void main(String[] args){

			Grille g1=new Grille(16,16); //choix de taille de la grille

			g1.afficher();

	}

	}

